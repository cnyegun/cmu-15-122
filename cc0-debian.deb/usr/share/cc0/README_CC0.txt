Welcome to CC0! This file is meant to be included with a CC0 distribution.

Dependencies:
 - libpng
 - zlib
 - gmp

These can be installed using brew or some other package manager

Contents:
 - bin/         cc0, coin
 - include/     files necessary for C code generation
 - lib/         standard libraries
 - runtime/     runtime libraries (C0RT, etc.)

To install, copy the four folders somewhere and add bin/ to $PATH.
Please keep the relative folders structure intact (e.g. bin/ include/ lib/ runtime/
should all be next to each other) 

